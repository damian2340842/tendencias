package WSoperation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Clasificacion;
import modelo.Persona;
import modelo.Usuario;
import modelo.Rol;
import modelo.Competencia;
import modelo.CompetenciaRol;
import modelo.Factura;
import modelo.Item_Factura;
import modelo.Producto;
import modelo.Proveedores;
import modelo.Tipo_pago;
import modelo.UsuarioRol;

@WebService(serviceName = "WSoperacionses")
public class WSoperacionses {
   Persona persona = new Persona();
    List<Persona> listaPersonas = persona.personas;
    Usuario nuevoUsuario = new Usuario();
    List<Usuario> listausuarios = nuevoUsuario.usuarios;
    List<Rol> listaRoles = new ArrayList<>();
    Rol rols = new Rol();
    ArrayList<Rol> rolesexistentes = rols.obtenerRoles;
    List<Factura> listaFacturas = new ArrayList<>();
    List<Item_Factura> listaitemFacturas = new ArrayList<>();
    ArrayList<Clasificacion> clasiexistentes = new ArrayList<>();
    Competencia compi = new Competencia();
    ArrayList<Competencia> competenciaexistentes = compi.competencias;
    ArrayList<Producto> productos = new ArrayList<>();
     ArrayList<Clasificacion> clasificaciones = new ArrayList<>();
      ArrayList<Proveedores> proveedores = new ArrayList<>();
         ArrayList<Tipo_pago> lista_tipos_pagos = new ArrayList<>();

    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
     @WebMethod(operationName = "registrarTipoPago")
    public Tipo_pago registrarTipoPago(
            @WebParam(name = "idTipoPago") Integer idTipoPago,
            @WebParam(name = "tipo") String tipo,
            @WebParam(name = "descripcion") String descripcion) {

        // Verificar si el ID de tipo de pago ya existe
        if (existeTipoPagoConId(idTipoPago)) {
            System.out.println("Error: El ID de tipo de pago ya está en uso.");
            return null;
        }

        // Crear una nueva instancia de Tipo_Pago
        Tipo_pago nuevoTipoPago = new Tipo_pago(idTipoPago, tipo, descripcion);

        // Agregar el nuevo tipo de pago a la lista
        lista_tipos_pagos.add(nuevoTipoPago);

        System.out.println("Registro exitoso: Tipo de pago registrado correctamente.");
        return nuevoTipoPago;
    }

    // Método para verificar la existencia de un tipo de pago con un ID específico
  private boolean existeTipoPagoConId(int idTipoPago) {
    for (Tipo_pago tipoPago : lista_tipos_pagos) {
        if (tipoPago.getId_tipo_pago() == idTipoPago) {
            return true;
        }
    }
    return false;
}

    @WebMethod(operationName = "estadorol")
    public Boolean estadorol(@WebParam(name = "nombrerol") String nombrerol) {
        Rol role = new Rol();

        ArrayList<Rol> estadospornombre = role.getRoles1();

        for (Rol rols : estadospornombre) {
            if (rols.getRoles1().equals(nombrerol)) {
                return rols.isEstado();
            }

        }
        return null;
    }

    @WebMethod(operationName = "siexisteComp")
    public Boolean siexisteComp(@WebParam(name = "idcomp") String idcomp) {
        Competencia competencia1 = new Competencia();

        ArrayList<Competencia> competenciasExistentes = competencia1.getCompetencias1();

        for (Competencia comps : competenciasExistentes) {
            if (comps.getCompetencias1().equals(idcomp)) {
                return true;
            }

        }
        return false;
    }
    private ArrayList<UsuarioRol> bd_tabla_usuario_rol = new ArrayList<>();
    private ArrayList<CompetenciaRol> bd_tabla_competencia_rol = new ArrayList<>();

    @WebMethod(operationName = "siexisterol")
    public Boolean siexisterol(@WebParam(name = "nombre") String nombre) {

        Rol rol2 = new Rol(1, "admin", true);
        Rol rol3 = new Rol(2, "cliente", true);
        Rol rol4 = new Rol(3, "empleado", true);
        Rol rol5 = new Rol(4, "vendedor", true);
        Rol rol6 = new Rol(5, "secretaria", true);
        rols.obtenerRoles.add(rol2);
        rols.obtenerRoles.add(rol3);
        rols.obtenerRoles.add(rol4);
        rols.obtenerRoles.add(rol5);
        rols.obtenerRoles.add(rol6);

        for (Rol rols : rolesexistentes) {
            if (rols.getRol().equals(nombre)) {
                return true;
            }

        }
        return false;
    }
     @WebMethod(operationName = "registrarProveedorYClasificacion")
    public String registrarProveedorYClasificacion(
            @WebParam(name = "idProveedor") int idProveedor,
            @WebParam(name = "ruc") String ruc,
            @WebParam(name = "telefono") String telefono,
            @WebParam(name = "pais") String pais,
            @WebParam(name = "correo") String correo,
            @WebParam(name = "moneda") String moneda,
            @WebParam(name = "grupoClasificacion") String grupoClasificacion) {

        // Verificar si el ID de proveedor o clasificación ya existe
        if (existeProveedorConId(idProveedor) || existeClasificacionConId(idProveedor)) {
            return "Error: El ID de proveedor o clasificación ya está en uso.";
        }

        // Crear una nueva instancia de Clasificacion
        Clasificacion nuevaClasificacion = new Clasificacion(idProveedor, grupoClasificacion);

        // Crear una nueva instancia de Proveedores
        Proveedores nuevoProveedor = new Proveedores(idProveedor, ruc, telefono, pais, correo, moneda, nuevaClasificacion);

        // Agregar la nueva clasificación a la lista de clasificaciones
        clasificaciones.add(nuevaClasificacion);

        // Agregar el nuevo proveedor a la lista de proveedores
        proveedores.add(nuevoProveedor);

        return "Registro exitoso: Proveedor y clasificación registrados correctamente.";
    }

    // Método para verificar la existencia de un proveedor con un ID específico
    private boolean existeProveedorConId(int idProveedor) {
        for (Proveedores proveedor : proveedores) {
            if (proveedor.getId_proveedores()== idProveedor) {
                return true;
            }
        }
        return false;
    }

    // Método para verificar la existencia de una clasificación con un ID específico
    private boolean existeClasificacionConId(int idClasificacion) {
        for (Clasificacion clasificacion : clasificaciones) {
            if (clasificacion.getId_clasificacion() == idClasificacion) {
                return true;
            }
        }
        return false;
    }

    @WebMethod(operationName = "registrarCompetenciaRol")
    public String registrarCompetenciaRol(
            @WebParam(name = "idRol") int idRol,
            @WebParam(name = "nombreRol1") String nombreRol1,
            @WebParam(name = "estadoRol") boolean estadoRol,
            @WebParam(name = "idCompetencia") int idCompetencia,
            @WebParam(name = "nombreCompetencia") String nombreCompetencia,
            @WebParam(name = "estado") boolean estadoCompetencia,
            @WebParam(name = "idClasificacion") int idClasificacion,
            @WebParam(name = "grupoClasificacion") String grupoClasificacion,
                        @WebParam(name = "desccompe") String desccompe) {

        try {

            Rol rolExistente = null;
            for (Rol rol : rolesexistentes) {
                if (rol.getId_rol() == idRol) {
                    rolExistente = rol;
                    break;
                }
            }

            if (rolExistente == null) {
                rolExistente = new Rol(idRol, nombreRol1, estadoRol);
                rolesexistentes.add(rolExistente);
            }

            // Verificar si la competencia ya existe
            Competencia competenciaExistente = null;
            for (Competencia competencia : competenciaexistentes) {
                if (competencia.getId_competencias()== idCompetencia) {
                    competenciaExistente = competencia;
                    break;
                }
            }

            if (competenciaExistente == null) {
                competenciaExistente = new Competencia(competenciaexistentes, idCompetencia, nombreRol1, desccompe, estadoRol);
                competenciaexistentes.add(competenciaExistente);
            }

            Clasificacion clasificacion = new Clasificacion(idClasificacion, grupoClasificacion);
            clasiexistentes.add(clasificacion);

            CompetenciaRol competenciaRol = new CompetenciaRol(rolExistente, competenciaExistente);
            bd_tabla_competencia_rol.add(competenciaRol);

            return "Registro exitoso: Rol, Competencia y Clasificación registrados correctamente.";
        } catch (Exception e) {
            // Manejo de la excepción
            e.printStackTrace();
            return "Error al registrar la relación Competencia-Rol.";
        }
    }

    @WebMethod(operationName = "registrarUsuarioPersonaRol")
    public Boolean registrarUsuarioPersonaRol(
            @WebParam(name = "idUsuario") int idUsuario,
            @WebParam(name = "idPersona") int idPersona,
            @WebParam(name = "nombreUsuario") String nombreUsuario,
            @WebParam(name = "passwordUsuario") String passwordUsuario,
            @WebParam(name = "nombrePersona") String nombrePersona,
            @WebParam(name = "apellidoPersona") String apellidoPersona,
            @WebParam(name = "dniPersona") String dniPersona,
            @WebParam(name = "celularPersona") String celularPersona,
            @WebParam(name = "correoPersona") String correoPersona,
            @WebParam(name = "idRol") int idRol,
            @WebParam(name = "nombreRol") String nombreRol,
            @WebParam(name = "estadoRol") boolean estadoRol) {

        Persona nuevaPersona = new Persona(idPersona, nombrePersona, apellidoPersona, dniPersona, celularPersona, correoPersona);

        Rol nuevoRol = new Rol(idRol, nombreRol, estadoRol);
        // Verificar si el rol ya existe
        Rol rolExistente = null;
        for (Rol rol : listaRoles) {
            if (rol.getId_rol() == idRol) {
                rolExistente = rol;
                break;
            }
        }

        if (rolExistente == null) {
            return false;
        }
        Usuario nuevoUsuario2 = new Usuario(idUsuario, idPersona, nombreUsuario, passwordUsuario, nuevaPersona);

        if (nuevoUsuario.existeUsuario(nombreUsuario)) {
            return false;
        } else {

            listausuarios.add(nuevoUsuario2);
            listaPersonas.add(nuevaPersona);
            listaRoles.add(nuevoRol);
            UsuarioRol usuariorol = new UsuarioRol(nuevoUsuario2, nuevoRol);
            bd_tabla_usuario_rol.add(usuariorol);

            return true;
        }
    }

    @WebMethod(operationName = "registrarrol")
    public String registrarrol(
            @WebParam(name = "rolnombre") String rolnombre,
            @WebParam(name = "estado") boolean estado,
            @WebParam(name = "id") int id) {

        try {
            // Crear una nueva instancia de Rol
            Rol rol = new Rol(id, rolnombre, estado);

            // Verificar si el rol ya existe
            for (Rol rols : rolesexistentes) {
                if (rols.getId_rol() == id) {
                    return "El rol con el mismo ID ya existe. No se puede registrar.";
                }
            }

            // Agregar el nuevo rol a la lista
            rolesexistentes.add(rol);
            return "Éxito al registrar el rol";
        } catch (Exception e) {
            // Manejo de la excepción
            e.printStackTrace(); // Imprime la traza de la excepción (puedes cambiar esto según tus necesidades)
            return "Error al registrar el rol";
        }
    }

    @WebMethod(operationName = "loginUsuario")
    public String loginUsuario(
            @WebParam(name = "nombreUsuario") String nombreUsuario,
            @WebParam(name = "passwordUsuario") String passwordUsuario) {

        String rol = "";
        Usuario usuarioEncontrado = null;
        for (UsuarioRol usuario : bd_tabla_usuario_rol) {
            if (usuario.getId_usuario().getUser().equals(nombreUsuario) && usuario.getId_usuario().getPassword().equals(passwordUsuario)) {
                usuarioEncontrado = usuario.getId_usuario();
                rol = usuario.getId_rol().getRol();

            }
        }

        // Verificar si se encontró el usuario
        if (usuarioEncontrado != null) {
            // Obtener el nombre de usuario
            String nombre = usuarioEncontrado.getPersona().getNombre();

            // Devolver información
            return "Login exitoso. Usuario: " + nombre + " y su rol es: " + rol;
        } else {
            // Usuario no encontrado
            return "Usuario o contraseña incorrectos. Por favor, verifica tus credenciales.";
        }
    }

    @WebMethod(operationName = "buscarP")
    public Persona buscarP(@WebParam(name = "dni") String dni) {

        if (persona.buscarPorDni(dni) != null) {
            return persona.buscarPorDni(dni);
        }

        return null;
    }
    //rucaumenta001

    @WebMethod(operationName = "crearProducto")
    public boolean crearProducto(
            @WebParam(name = "idProducto") int idProducto,
            @WebParam(name = "stock") int stock,
            @WebParam(name = "precioUnitario") double precioUnitario,
            @WebParam(name = "unidad") String unidad,
            @WebParam(name = "idClasificacion") Clasificacion idClasificacion,
            @WebParam(name = "idProveedor") Proveedores idProveedor,
            @WebParam(name = "iva") boolean iva,
            @WebParam(name = "foto") String foto) {

        Producto nuevoProducto = new Producto(idProducto, stock, idProducto, idProducto, precioUnitario, unidad, iva, foto);

        productos.add(nuevoProducto);

        return true;
    }

    @WebMethod(operationName = "registrarFacturaConItems")
    public String registrarFacturaConItems(
            @WebParam(name = "id_Factura") Integer id_Factura,
            @WebParam(name = "ruc") String ruc,
            @WebParam(name = "idPersona") Persona id_Persona,
            @WebParam(name = "fecha") String fecha,
            @WebParam(name = "id_tipo_pago") Tipo_pago id_tipo_pago,
            @WebParam(name = "descuento") Double descuento,
            @WebParam(name = "total") Double total,
            @WebParam(name = "itemsFactura") List<Item_Factura> itemsFactura) {

        try {
            // Transformar la cadena de fecha a tipo Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date fechaDate = sdf.parse(fecha);
 
            Factura nuevaFactura = new Factura(id_Factura, ruc, fechaDate, descuento, total, id_Persona, id_tipo_pago);

            // Agregar la nueva factura a la lista
            listaFacturas.add(nuevaFactura);

            // Asignar la factura a cada ítem y agregar los ítems a la lista
            for (Item_Factura itemFactura : itemsFactura) {
                // Asignar la factura al ítem
                itemFactura.setId_factura(nuevaFactura);

                // Verificar si el producto ya existe, si no, agregarlo
                Producto productoExistente = null;
                for (Producto producto : productos) {
                    if (producto.getId_producto()== itemFactura.getId_producto().getId_producto()) {
                        productoExistente = producto;
                        break;
                    }
                }

                if (productoExistente == null) {
                    productos.add(itemFactura.getId_producto());
                }

                // Agregar el ítem a la lista
                listaitemFacturas.add(itemFactura);
            }

            return "Factura y items registrados con éxito.";
        } catch (Exception e) {
            // Manejo de la excepción
            e.printStackTrace();
            return "Error al registrar la factura y los items.";
        }
    }
    //listados
      @WebMethod(operationName = "listarPersonas")
    public List<Persona> listarPersonas() {
        return listaPersonas;
    }

    @WebMethod(operationName = "listarUsuarios")
    public List<Usuario> listarUsuarios() {
        return listausuarios;
    }

    @WebMethod(operationName = "listarRoles")
    public List<Rol> listarRoles() {
        return listaRoles;
    }

    @WebMethod(operationName = "listarRolesExistentes")
    public List<Rol> listarRolesExistentes() {
        return rolesexistentes;
    }

    @WebMethod(operationName = "listarFacturas")
    public List<Factura> listarFacturas() {
        return listaFacturas;
    }

    @WebMethod(operationName = "listarItemFacturas")
    public List<Item_Factura> listarItemFacturas() {
        return listaitemFacturas;
    }

    @WebMethod(operationName = "listarClasificacionesExistentes")
    public List<Clasificacion> listarClasificacionesExistentes() {
        return clasiexistentes;
    }

    @WebMethod(operationName = "listarCompetenciasExistentes")
    public List<Competencia> listarCompetenciasExistentes() {
        return competenciaexistentes;
    }

    @WebMethod(operationName = "listarProductos")
    public List<Producto> listarProductos() {
        return productos;
    }

    @WebMethod(operationName = "listarClasificaciones")
    public List<Clasificacion> listarClasificaciones() {
        return clasificaciones;
    }

    @WebMethod(operationName = "listarProveedores")
    public List<Proveedores> listarProveedores() {
        return proveedores;
    }

    @WebMethod(operationName = "listarTiposPagos")
    public List<Tipo_pago> listarTiposPagos() {
        return lista_tipos_pagos;
    }

    @WebMethod(operationName = "listarTablaUsuarioRol")
    public List<UsuarioRol> listarTablaUsuarioRol() {
        return bd_tabla_usuario_rol;
    }

    @WebMethod(operationName = "listarTablaCompetenciaRol")
    public List<CompetenciaRol> listarTablaCompetenciaRol() {
        return bd_tabla_competencia_rol;
    }
}
