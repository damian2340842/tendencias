/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author Damian
 */
public class Factura {
    private int id_factura;
    private String ruc;
    private Date fecha;
    private double descuento,total;
    private Persona id_persona;
    private Tipo_pago id_tipo_pago;

    public Factura() {
    }

    public Factura(int id_factura, String ruc, Date fecha, double descuento, double total, Persona id_persona, Tipo_pago id_tipo_pago) {
        this.id_factura = id_factura;
        this.ruc = ruc;
        this.fecha = fecha;
        this.descuento = descuento;
        this.total = total;
        this.id_persona = id_persona;
        this.id_tipo_pago = id_tipo_pago;
    }

   

    

    

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    public Persona getId_persona() {
        return id_persona;
    }

    public void setId_persona(Persona id_persona) {
        this.id_persona = id_persona;
    }

    public Tipo_pago getId_tipo_pago() {
        return id_tipo_pago;
    }

    public void setId_tipo_pago(Tipo_pago id_tipo_pago) {
        this.id_tipo_pago = id_tipo_pago;
    }

    

   

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    //este metodo nos sirve para tranformar todos los datos en  Strin y asi poder guardarlos y consultarlos
    @Override
    public String toString() {
        return "Factura{" + "id_factura=" + id_factura + ", ruc=" + ruc + ", id_persona=" + id_persona + ", fecha=" + fecha + ", id_tipo_pago=" + id_tipo_pago + ", descuento=" + descuento + ", total=" + total + '}';
    } 
}
