/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Damian
 */
public class CompetenciaRol {
   
    private Rol roles;
    private Competencia competencias;

    public CompetenciaRol() {
    }

    public CompetenciaRol(Rol roles, Competencia competencias) {
        this.roles = roles;
        this.competencias = competencias;
    }
    
  
    
    

    

    public Rol getRoles() {
        return roles;
    }

    public void setRoles(Rol roles) {
        this.roles = roles;
    }

    public Competencia getCompetencias() {
        return competencias;
    }

    public void setCompetencias(Competencia competencias) {
        this.competencias = competencias;
    }

    
}
