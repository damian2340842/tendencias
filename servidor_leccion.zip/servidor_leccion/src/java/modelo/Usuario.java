/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Damian
 */
public class Usuario {

    private int id_usuario1, id_persona;
    private String user, password;
    private Persona persona;
    
    
    public ArrayList<Usuario> usuarios = new ArrayList<>();

    public Usuario() {
    }

    public Usuario(int id_usuario1, int id_persona, String user, String password, Persona persona) {
        this.id_usuario1 = id_usuario1;
        this.id_persona = id_persona;
        this.user = user;
        this.password = password;
        this.persona = persona;
    }

    public ArrayList<Usuario> getUsuarios1() {
        return usuarios;
    }

    public void setUsuarios(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public int getId_usuario1() {
        return id_usuario1;
    }

    public void setId_usuario1(int id_usuario1) {
        this.id_usuario1 = id_usuario1;
    }

    public int getId_persona() {
        return id_persona;
    }

    public void setId_persona(int id_persona) {
        this.id_persona = id_persona;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Persona getPersona() {
        return persona;
    }

    /**
     * @param persona the persona to set
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public boolean existeUsuario(String nombreUsuario) {
        return usuarios.stream().anyMatch(usuario -> usuario.getUser().equals(nombreUsuario));
    }
}
