/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Damian
 */
public class Persona {
    private int id_persona;
    private String nombre,apellido,dni,celular,correo;
    public   ArrayList<Persona> personas=new ArrayList<>();

    public Persona() {
    }

    public Persona(int id_persona, String nombre, String apellido, String dni, String celular, String correo) {
        this.id_persona = id_persona;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.celular = celular;
        this.correo = correo;
    }

    public int getId_persona() {
        return id_persona;
    }

    public void setId_persona(int id_persona) {
        this.id_persona = id_persona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public Persona buscarPorDni(String dni) {
        for (Persona persona : personas) {
            if (persona.getDni().equals(dni)) {
                return persona;
            }
        }
        return null;
    }

    public ArrayList<String> buscarNombresPorDni(String dni) {
        ArrayList<String> nombresEncontrados = new ArrayList<>();

        for (Persona persona : personas) {
            if (persona.getDni().equals(dni)) {
                String nombreCompleto = persona.getNombre() + " " + persona.getApellido();
                nombresEncontrados.add(nombreCompleto);
            }
        }

        return nombresEncontrados.isEmpty() ? null : nombresEncontrados;
    }
}
