/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Damian
 */
public class Item_Factura {
    
   private int id_item_factura,cantidad;
   private double precio,subtotal;
 private Factura id_factura;
    private Producto id_producto;

    public Item_Factura(int id_item_factura, int cantidad, double precio, double subtotal, Factura id_factura, Producto id_producto) {
        this.id_item_factura = id_item_factura;
        this.cantidad = cantidad;
        this.precio = precio;
        this.subtotal = subtotal;
        this.id_factura = id_factura;
        this.id_producto = id_producto;
    }
   

    public Item_Factura() {
    }

    public int getId_item_factura() {
        return id_item_factura;
    }

    public void setId_item_factura(int id_item_factura) {
        this.id_item_factura = id_item_factura;
    }

    public Factura getId_factura() {
        return id_factura;
    }

    public void setId_factura(Factura id_factura) {
        this.id_factura = id_factura;
    }

    public Producto getId_producto() {
        return id_producto;
    }

    public void setId_producto(Producto id_producto) {
        this.id_producto = id_producto;
    }

   
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }
   
}
