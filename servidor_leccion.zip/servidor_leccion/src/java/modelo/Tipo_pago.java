/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Damian
 */
public class Tipo_pago {
   private Integer  id_tipo_pago;
private String tipo,descrip;

    public Tipo_pago() {
    }

    public Tipo_pago(int id_tipo_pago, String tipo, String descrip) {
        this.id_tipo_pago = id_tipo_pago;
        this.tipo = tipo;
        this.descrip = descrip;
    }

    public int getId_tipo_pago() {
        return id_tipo_pago;
    }

    public void setId_tipo_pago(int id_tipo_pago) {
        this.id_tipo_pago = id_tipo_pago;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }
@Override
    public String toString() {
        return "Tipo_Pago{" + "id_tipo_pago=" + id_tipo_pago + ", tipo=" + tipo + ", descrip=" + descrip + '}';
    }
}
