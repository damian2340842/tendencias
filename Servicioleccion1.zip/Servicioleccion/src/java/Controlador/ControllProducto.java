/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vistas.ProductoV;
import Vistas.Registro;

/**
 *
 * @author Damian
 */
public class ControllProducto {
     private ProductoV productovista;

    public ControllProducto(ProductoV productovista) {
        this.productovista = productovista;
    }

    public void IniciarControl() {
        productovista.setTitle("MENU");
        productovista.setVisible(true);
        productovista.setLocationRelativeTo(null);

        productovista.getBtncrearp().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Registro rl = new Registro();
                ControllRegistro cr1 = new ControllRegistro(rl);
                cr1.IniciarControl();
            }
        });
    }
}

