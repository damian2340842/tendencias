/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vistas.Login;
import Vistas.Menu;
import Vistas.Registro;
import Controlador.ControllRegistro;

/**
 *
 * @author Damian
 */
public class ControllLogin {

    private Login loginvista;

    public ControllLogin(Login loginvista) {
        this.loginvista = loginvista;
    }

    public void IniciarControl() {
        loginvista.setTitle("Login");
        loginvista.setVisible(true);
        loginvista.setLocationRelativeTo(null);

        loginvista.getTxtpassword().addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                if (evt.getKeyChar() == '\n') {
                    IniciarSesion();
                }
            }
        });

        loginvista.getTxtusuario().addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                if (evt.getKeyChar() == '\n') {
                    IniciarSesion();
                }
            }
        });

        loginvista.getBtnregistro().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegistrarseBtn();
            }
        });

        loginvista.getBtninicio().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                IniciarSesion();
            }
        });
    }

    public void IniciarSesion() {
        loginvista.dispose();
        Menu ml = new Menu();
        ControllMenu cr1 = new ControllMenu(ml);
        cr1.IniciarControl();
    }

    public void RegistrarseBtn() {
        loginvista.dispose();
        Registro rl = new Registro();
        ControllRegistro cr1 = new ControllRegistro(rl);
        cr1.IniciarControl();
    }
}
