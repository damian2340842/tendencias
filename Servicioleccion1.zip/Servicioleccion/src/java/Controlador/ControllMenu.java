/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vistas.Menu;
import Vistas.ProductoV;

/**
 *
 * @author Damian
 */
public class ControllMenu {
     private Menu menuvista;

    public ControllMenu(Menu menuvista) {
        this.menuvista = menuvista;
    }

    public void IniciarControl() {
        
        menuvista.setTitle("MENU");
        menuvista.setVisible(true);
        menuvista.setLocationRelativeTo(null);

        menuvista.getBtnproductos().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProductoV pl = new ProductoV();
                ControllProducto cp1 = new ControllProducto(pl);
                cp1.IniciarControl();
            }
        });
    }
}


