/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import wsoperation.Factura;

/**
 *
 * @author Damian
 */
public class ControllFactura {
    private Factura facturavista;

    public ControllFactura(Factura facturavista) {
        this.facturavista = facturavista;
    }

    /*public void IniciarControl() {
        facturavista.setTitle("MENU");
        facturavista.setVisible(true);
        facturavista.setLocationRelativeTo(null);

        facturavista.getBtncrearp().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Registro rl = new Registro();
                ControllRegistro cr1 = new ControllRegistro(rl);
                cr1.IniciarControl();
            }
        });
    }*/
}

