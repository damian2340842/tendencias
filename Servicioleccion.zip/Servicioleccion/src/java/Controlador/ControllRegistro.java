/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vistas.Login;
import Vistas.Registro;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.JOptionPane;
import wsoperation.Rol;
import wsoperation.WSoperacionses;
import wsoperation.WSoperacionses_Service;
/**
 *
 * @author Damian
 */
public class ControllRegistro {
    WSoperacionses_Service servicio = new WSoperacionses_Service();
    WSoperacionses app = servicio.getWSoperacionsesPort();
    
    private Registro registrovista;
    int idRol = app.listarRoles().size();
    int idUsuario = app.listarUsuarios().size();
    ; // Debes implementar tu propia lógica para obtener el próximo ID
    int idPersona = app.listarPersonas().size();

   /* public ControllRegistro(Registro registrovista) {
        this.registrovista = registrovista;
    }*/
    
    public void IniciarControl() {
        registrovista.setTitle("Registro");
        registrovista.setVisible(true);
        registrovista.setLocationRelativeTo(null);
        registrovista.getBtnvolver().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VolverBtn();
            }
        });
        registrovista.getBtnregistrarse().addActionListener(l -> RegistrarseBtn());
        registrovista.getTxtNombreR().addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char caracter = evt.getKeyChar();

                if (!Character.isLetter(caracter) && caracter != KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
        registrovista.getTxtapellidoR().addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char caracter = evt.getKeyChar();

                if (!Character.isLetter(caracter) && caracter != KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
        registrovista.getTxtcedulaR().addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char caracter = evt.getKeyChar();
                // Solo permitir números y el backspace
                if (!Character.isDigit(caracter) && caracter != KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
        registrovista.getTxtCelularR().addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char caracter = evt.getKeyChar();
                // Solo permitir números y el backspace
                if (!Character.isDigit(caracter) && caracter != KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });

        llenarComboBoxRoles();
        registrovista.getBtnregistrarse().addActionListener(l -> RegistrarseBtn());
    }
    
    private void llenarComboBoxRoles() {

        List<Rol> roles = app.listarRoles();

        registrovista.getComboRolR().removeAllItems();

        for (Rol rol : roles) {
            registrovista.getComboRolR().addItem(rol.getRol());
        }
    }


    public void RegistrarseBtn() {
        // Obtener los datos del usuario
        int idUsuario = obtenerProximoIdUsuario(); 
        int idPersona = obtenerProximoIdPersona(); 
        String nombreUsuario = registrovista.getTxtusuarioR().getText();
        String contraseña = new String(registrovista.getTxtContrasenaR().getText());
        String nombrePersona = registrovista.getTxtNombreR().getText();
        String apellidoPersona = registrovista.getTxtapellidoR().getText();
        String dniPersona = registrovista.getTxtcedulaR().getText();
        String celularPersona = registrovista.getTxtCelularR().getText();
        String correoPersona = registrovista.getTxtcorreoR().getText();

        // datos de la persona...
        idRol = obtenerProximoIdRol(); // Debes implementar tu propia lógica para obtener el próximo ID
        String nombreRol = registrovista.getComboRolR().getSelectedItem().toString();
        boolean estadoRol = true;
        System.out.println(idUsuario + " idUsuario");
        System.out.println(idPersona + " idPersona");

        // Check for empty fields
        if (nombreUsuario.equals("") || contraseña.equals("") || nombrePersona.equals("") ||
                apellidoPersona.equals("") || dniPersona.equals("") || celularPersona.equals("") ||
                correoPersona.equals("")) {
            JOptionPane.showMessageDialog(null, "Existen campos sin llenar ");
        } else {
            // Perform registration only if fields are not empty
            // Update: Check if registration is successful using the appropriate condition
            if (app.registrarUsuarioPersonaRol(1, 1, nombreUsuario, contraseña, nombrePersona, apellidoPersona,
                    dniPersona, celularPersona, correoPersona, 0, nombreRol, true)) {
                JOptionPane.showMessageDialog(null, "Datos guardados correctamente");
                // TODO: Add logic to save data or call other methods as needed
            } else {
                JOptionPane.showMessageDialog(null, "Error al Guardar");
            }
        }
       
      
    }
    
    
    public int obtenerProximoIdUsuario(){
        idUsuario =  idUsuario+1;
        
        return idUsuario;
    }
    public int obtenerProximoIdPersona(){
        idPersona =  idPersona+1;
        
        return idPersona;
    }
    public int obtenerProximoIdRol(){
        idRol = idRol +1;
        return idRol;
    }
    public void VolverBtn() {
        registrovista.dispose();;
        Login vl = new Login();
        ControllLogin ctl = new ControllLogin(vl);
        ctl.IniciarControl();
    }
    
    
  
}