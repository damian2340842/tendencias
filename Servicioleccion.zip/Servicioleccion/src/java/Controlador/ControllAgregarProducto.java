/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vistas.AgregarProductos;

/**
 *
 * @author Damian
 */
public class ControllAgregarProducto {
    private AgregarProductos agregarproductos;

    public ControllAgregarProducto(AgregarProductos agregarproductos) {
        this.agregarproductos = agregarproductos;
    }

    public void IniciarControl() {
        agregarproductos.setTitle("Agregar nuevo producto");
        agregarproductos.setVisible(true);
        agregarproductos.setLocationRelativeTo(null);

        agregarproductos.getBtnGuardar().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                
            }
        });
    }
}