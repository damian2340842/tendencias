/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Validaciones;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;

import javax.swing.JSpinner;
/**
 *
 * @author Damian
 */
public class Numeros {
   
    public static void solo_numeros(JTextField t) {
        t.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (e.getKeyChar() < 45 || e.getKeyChar() > 57||e.getKeyChar()==47||e.getKeyChar()==45) {
                    e.consume();
                }
            }
        }
        );
    }
    public static void solo_numerosspiner(JSpinner t) {
        t.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (e.getKeyChar() < 48 || e.getKeyChar() > 57) {
                    e.consume();
                }
            }
        }
        );
    }
}